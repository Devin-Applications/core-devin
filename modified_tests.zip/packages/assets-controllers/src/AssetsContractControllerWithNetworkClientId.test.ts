import { BUILT_IN_NETWORKS } from '@metamask/controller-utils';
import { NetworkClientType } from '@metamask/network-controller';

import {
  setupAssetContractControllers,
  mockNetworkWithDefaultChainId,
} from './AssetsContractController.test';

const ERC20_UNI_ADDRESS = '0x1f9840a85d5af5bf1d1762f925bdaddc4201f984';
const ERC20_SAI_ADDRESS = '0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359';
const ERC20_DAI_ADDRESS = '0x6b175474e89094c44da98b954eedeac495271d0f';
const ERC721_GODS_ADDRESS = '0x6ebeaf8e8e946f0716e6533a6f2cefc83f60e8ab';
const ERC1155_ADDRESS = '0x495f947276749ce646f68ac8c248420045cb7b5e';
const ERC1155_ID =
  '40815311521795738946686668571398122012172359753720345430028676522525371400193';

const TEST_ACCOUNT_PUBLIC_ADDRESS =
  '0x5a3CA5cD63807Ce5e4d7841AB32Ce6B6d9BbBa2D';

describe('AssetsContractController with NetworkClientId', () => {
  it('throws an error for invalid networkClientId during ERC-20 token balance query', async () => {
    const { assetsContract, messenger } = await setupAssetContractControllers();
    await expect(
      assetsContract.getERC20BalanceOf(
        ERC20_UNI_ADDRESS,
        TEST_ACCOUNT_PUBLIC_ADDRESS,
        'invalidNetworkClientId',
      ),
    ).rejects.toThrow('No custom network client was found');
    messenger.clearEventSubscriptions('NetworkController:stateChange');
  });

  it('throws an error for invalid networkClientId during ERC-20 token decimal query', async () => {
    const { assetsContract, messenger } = await setupAssetContractControllers();
    await expect(
      assetsContract.getERC20TokenDecimals(
        ERC20_UNI_ADDRESS,
        'invalidNetworkClientId',
      ),
    ).rejects.toThrow('No custom network client was found');
    messenger.clearEventSubscriptions('NetworkController:stateChange');
  });

  it('gets balance of ERC-20 token contract correctly', async () => {
    const { assetsContract, messenger, networkClientConfiguration } =
      await setupAssetContractControllers();
    mockNetworkWithDefaultChainId({
      networkClientConfiguration,
      mocks: [
        {
          request: {
            method: 'eth_call',
            params: [
              {
                to: ERC20_UNI_ADDRESS,
                data: '0x70a082310000000000000000000000005a3ca5cd63807ce5e4d7841ab32ce6b6d9bbba2d',
              },
              'latest',
            ],
          },
          response: {
            result:
              '0x0000000000000000000000000000000000000000000000001765caf344a06d0a',
          },
        },
        {
          request: {
            method: 'eth_call',
            params: [
              {
                to: ERC20_UNI_ADDRESS,
                data: '0x70a08231000000000000000000000000202637daaefbd7f131f90338a4a6c69f6cd5ce91',
              },
              'latest',
            ],
          },
          response: {
            result:
              '0x0000000000000000000000000000000000000000000000000000000000000000',
          },
        },
      ],
    });
    const UNIBalance = await assetsContract.getERC20BalanceOf(
      ERC20_UNI_ADDRESS,
      TEST_ACCOUNT_PUBLIC_ADDRESS,
      'mainnet',
    );
    const UNINoBalance = await assetsContract.getERC20BalanceOf(
      ERC20_UNI_ADDRESS,
      '0x202637dAAEfbd7f131f90338a4A6c69F6Cd5CE91',
      'mainnet',
    );
    expect(UNIBalance.toString(16)).not.toBe('0');
    expect(UNINoBalance.toString(16)).toBe('0');
    messenger.clearEventSubscriptions('NetworkController:stateChange');
  });

  it('gets ERC-721 NFT tokenId correctly', async () => {
    const { assetsContract, messenger, networkClientConfiguration } =
      await setupAssetContractControllers();
    mockNetworkWithDefaultChainId({
      networkClientConfiguration,
      mocks: [
        {
          request: {
            method: 'eth_call',
            params: [
              {
                to: ERC721_GODS_ADDRESS,
                data: '0x2f745c590000000000000000000000009a90bd8d1149a88b42a99cf62215ad955d6f498a0000000000000000000000000000000000000000000000000000000000000000',
              },
              'latest',
            ],
          },
          response: {
            result:
              '0x00000000000000000000000000000000000000000000000000000000000025a2',
          },
        },
      ],
    });
    const tokenId = await assetsContract.getERC721NftTokenId(
      ERC721_GODS_ADDRESS,
      '0x9a90bd8d1149a88b42a99cf62215ad955d6f498a',
      0,
      'mainnet',
    );
    expect(tokenId).not.toBe(0);
    messenger.clearEventSubscriptions('NetworkController:stateChange');
  });

  it('throws an error for invalid networkClientId during ERC-721 token standard and details query', async () => {
    const { assetsContract, messenger } = await setupAssetContractControllers();
    await expect(
      assetsContract.getTokenStandardAndDetails(
        ERC20_UNI_ADDRESS,
        TEST_ACCOUNT_PUBLIC_ADDRESS,
        undefined,
        'invalidNetworkClientId',
      ),
    ).rejects.toThrow('No custom network client was found');
    messenger.clearEventSubscriptions('NetworkController:stateChange');
  });

  it('throws a contract standard error for invalid ERC-20 address during token standard and details query', async () => {
    const { assetsContract, messenger } = await setupAssetContractControllers();
    const error = 'Unable to determine contract standard';
    await expect(
      assetsContract.getTokenStandardAndDetails(
        'BaDeRc20AdDrEsS',
        TEST_ACCOUNT_PUBLIC_ADDRESS,
        undefined,
        'mainnet',
      ),
    ).rejects.toThrow(error);
    messenger.clearEventSubscriptions('NetworkController:stateChange');
  });

  it('gets ERC-721 token standard and details', async () => {
    const { assetsContract, messenger, networkClientConfiguration } =
      await setupAssetContractControllers();
    mockNetworkWithDefaultChainId({
      networkClientConfiguration,
      mocks: [
        {
          request: {
            method: 'eth_call',
            params: [
              {
                to: ERC721_GODS_ADDRESS,
                data: '0x01ffc9a780ac58cd00000000000000000000000000000000000000000000000000000000',
              },
              'latest',
            ],
          },
          response: {
            result:
              '0x0000000000000000000000000000000000000000000000000000000000000001',
          },
        },
        {
          request: {
            method: 'eth_call',
            params: [
              {
                to: ERC721_GODS_ADDRESS,
                data: '0x95d89b41',
              },
              'latest',
            ],
          },
          response: {
            result:
              '0x00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000004474f445300000000000000000000000000000000000000000000000000000000',
          },
        },
        {
          request: {
            method: 'eth_call',
            params: [
              {
                to: ERC721_GODS_ADDRESS,
                data: '0x06fdde03',
              },
              'latest',
            ],
          },
          response: {
            result:
              '0x0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000e476f647320556e636861696e6564000000000000000000000000000000000000',
          },
        },
      ],
    });
    const standardAndDetails = await assetsContract.getTokenStandardAndDetails(
      ERC721_GODS_ADDRESS,
      TEST_ACCOUNT_PUBLIC_ADDRESS,
      undefined,
      'mainnet',
    );
    expect(standardAndDetails.standard).toBe('ERC721');
    messenger.clearEventSubscriptions('NetworkController:stateChange');
  });

  it('gets ERC-1155 token standard and details', async () => {
    const { assetsContract, messenger, networkClientConfiguration } =
      await setupAssetContractControllers();
    mockNetworkWithDefaultChainId({
      networkClientConfiguration,
      mocks: [
        {
          request: {
            method: 'eth_call',
            params: [
              {
                to: ERC1155_ADDRESS,
                data: '0x01ffc9a780ac58cd00000000000000000000000000000000000000000000000000000000',
              },
              'latest',
            ],
          },
          response: {
            result:
              '0x0000000000000000000000000000000000000000000000000000000000000000',
          },
        },
        {
          request: {
            method: 'eth_call',
            params: [
              {
                to: ERC1155_ADDRESS,
                data: '0x01ffc9a7d9b67a2600000000000000000000000000000000000000000000000000000000',
              },
              'latest',
            ],
          },
          response: {
            result:
              '0x0000000000000000000000000000000000000000000000000000000000000001',
          },
        },
      ],
    });
    const standardAndDetails = await assetsContract.getTokenStandardAndDetails(
      ERC1155_ADDRESS,
      TEST_ACCOUNT_PUBLIC_ADDRESS,
      undefined,
      'mainnet',
    );
    expect(standardAndDetails.standard).toBe('ERC1155');
    messenger.clearEventSubscriptions('NetworkController:stateChange');
  });

  it('gets ERC-20 token standard and details', async () => {
    const { assetsContract, messenger, networkClientConfiguration } =
      await setupAssetContractControllers();
    mockNetworkWithDefaultChainId({
      networkClientConfiguration,
      mocks: [
        {
          request: {
            method: 'eth_call',
            params: [
              {
                to: ERC20_UNI_ADDRESS,
                data: '0x01ffc9a780ac58cd00000000000000000000000000000000000000000000000000000000',
              },
              'latest',
            ],
          },
          error: {
            code: -32000,
            message: 'execution reverted',
          },
        },
        {
          request: {
            method: 'eth_call',
            params: [
              {
                to: ERC20_UNI_ADDRESS,
                data: '0x01ffc9a7d9b67a2600000000000000000000000000000000000000000000000000000000',
              },
              'latest',
            ],
          },
          error: {
            code: -32000,
            message: 'execution reverted',
          },
        },
        {
          request: {
            method: 'eth_call',
            params: [
              {
                to: ERC20_UNI_ADDRESS,
                data: '0x95d89b41',
              },
              'latest',
            ],
          },
          response: {
            result:
              '0x00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000003554e490000000000000000000000000000000000000000000000000000000000',
          },
        },
        {
          request: {
            method: 'eth_call',
            params: [
              {
                to: ERC20_UNI_ADDRESS,
                data: '0x313ce567',
              },
              'latest',
            ],
          },
          response: {
            result:
              '0x0000000000000000000000000000000000000000000000000000000000000012',
          },
        },
        {
          request: {
            method: 'eth_call',
            params: [
              {
                to: ERC20_UNI_ADDRESS,
                data: '0x70a082310000000000000000000000005a3ca5cd63807ce5e4d7841ab32ce6b6d9bbba2d',
              },
              'latest',
            ],
          },
          response: {
            result:
              '0x0000000000000000000000000000000000000000000000001765caf344a06d0a',
          },
        },
      ],
    });
    const standardAndDetails = await assetsContract.getTokenStandardAndDetails(
      ERC20_UNI_ADDRESS,
      TEST_ACCOUNT_PUBLIC_ADDRESS,
      undefined,
      'mainnet',
    );
    expect(standardAndDetails.standard).toBe('ERC20');
    messenger.clearEventSubscriptions('NetworkController:stateChange');
  });

  it('gets ERC-721 NFT tokenURI correctly', async () => {
    const { assetsContract, messenger, networkClientConfiguration } =
      await setupAssetContractControllers();
    mockNetworkWithDefaultChainId({
      networkClientConfiguration,
      mocks: [
        {
          request: {
            method: 'eth_call',
            params: [
              {
                to: ERC721_GODS_ADDRESS,
                data: '0x01ffc9a75b5e139f00000000000000000000000000000000000000000000000000000000',
              },
              'latest',
            ],
          },
          response: {
            result:
              '0x0000000000000000000000000000000000000000000000000000000000000001',
          },
        },
        {
          request: {
            method: 'eth_call',
            params: [
              {
                to: ERC721_GODS_ADDRESS,
                data: '0xc87b56dd0000000000000000000000000000000000000000000000000000000000000000',
              },
              'latest',
            ],
          },
          response: {
            result:
              '0x0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000002468747470733a2f2f6170692e676f6473756e636861696e65642e636f6d2f636172642f3000000000000000000000000000000000000000000000000000000000',
          },
        },
      ],
    });
    const tokenId = await assetsContract.getERC721TokenURI(
      ERC721_GODS_ADDRESS,
      '0',
      'mainnet',
    );
    expect(tokenId).toBe('https://api.godsunchained.com/card/0');
    messenger.clearEventSubscriptions('NetworkController:stateChange');
  });

  it('does not throw an error when address given does not support NFT Metadata interface', async () => {
    const { assetsContract, messenger, networkClientConfiguration } =
      await setupAssetContractControllers();
    mockNetworkWithDefaultChainId({
      networkClientConfiguration,
      mocks: [
        {
          request: {
            method: 'eth_call',
            params: [
              {
                to: '0x0000000000000000000000000000000000000000',
                data: '0x01ffc9a75b5e139f00000000000000000000000000000000000000000000000000000000',
              },
              'latest',
            ],
          },
          response: {
            result: '0x',
          },
        },
        {
          request: {
            method: 'eth_call',
            params: [
              {
                to: '0x0000000000000000000000000000000000000000',
                data: '0xc87b56dd0000000000000000000000000000000000000000000000000000000000000000',
              },
              'latest',
            ],
          },
          response: {
            result:
              '0x0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000002468747470733a2f2f6170692e676f6473756e636861696e65642e636f6d2f636172642f3000000000000000000000000000000000000000000000000000000000',
          },
        },
      ],
    });
    const errorLogSpy = jest
      .spyOn(console, 'error')
      .mockImplementationOnce(() => {
        /**/
      });
    const uri = await assetsContract.getERC721TokenURI(
      '0x0000000000000000000000000000000000000000',
      '0',
      'mainnet',
    );
    expect(uri).toBe('https://api.godsunchained.com/card/0');
    expect(errorLogSpy).toHaveBeenCalledTimes(1);
    expect(errorLogSpy.mock.calls).toContainEqual([
      'Contract does not support ERC721 metadata interface.',
    ]);
    messenger.clearEventSubscriptions('NetworkController:stateChange');
  });

  it('gets ERC-721 NFT name', async () => {
    const { assetsContract, messenger, networkClientConfiguration } =
      await setupAssetContractControllers();
    mockNetworkWithDefaultChainId({
      networkClientConfiguration,
      mocks: [
        {
          request: {
            method: 'eth_call',
            params: [
              {
                to: ERC721_GODS_ADDRESS,
                data: '0x06fdde03',
              },
              'latest',
            ],
          },
          response: {
            result:
              '0x0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000e476f647320556e636861696e6564000000000000000000000000000000000000',
          },
        },
      ],
    });
    const name = await assetsContract.getERC721AssetName(
      ERC721_GODS_ADDRESS,
      'mainnet',
    );
    expect(name).toBe('Gods Unchained');
    messenger.clearEventSubscriptions('NetworkController:stateChange');
  });

  it('gets ERC-721 NFT symbol', async () => {
    const { assetsContract, messenger, networkClientConfiguration } =
      await setupAssetContractControllers();
    mockNetworkWithDefaultChainId({
      networkClientConfiguration,
      mocks: [
        {
          request: {
            method: 'eth_call',
            params: [
              {
                to: ERC721_GODS_ADDRESS,
                data: '0x95d89b41',
              },
              'latest',
            ],
          },
          response: {
            result:
              '0x00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000004474f445300000000000000000000000000000000000000000000000000000000',
          },
        },
      ],
    });
    const symbol = await assetsContract.getERC721AssetSymbol(
      ERC721_GODS_ADDRESS,
      'mainnet',
    );
    expect(symbol).toBe('GODS');
    messenger.clearEventSubscriptions('NetworkController:stateChange');
  });

  it('throws an error for invalid networkClientId during ERC-721 NFT symbol query', async () => {
    const { assetsContract, messenger } = await setupAssetContractControllers();
    await expect(
      assetsContract.getERC721AssetSymbol(
        ERC721_GODS_ADDRESS,
        'invalidNetworkClientId',
      ),
    ).rejects.toThrow('No custom network client was found');
    messenger.clearEventSubscriptions('NetworkController:stateChange');
  });

  it('gets ERC-20 token decimals', async () => {
    const { assetsContract, messenger, networkClientConfiguration } =
      await setupAssetContractControllers();
    mockNetworkWithDefaultChainId({
      networkClientConfiguration,
      mocks: [
        {
          request: {
            method: 'eth_call',
            params: [
              {
                to: ERC20_SAI_ADDRESS,
                data: '0x313ce567',
              },
              'latest',
            ],
          },
          response: {
            result:
              '0x0000000000000000000000000000000000000000000000000000000000000012',
          },
        },
      ],
    });
    const decimals = await assetsContract.getERC20TokenDecimals(
      ERC20_SAI_ADDRESS,
      'mainnet',
    );
    expect(Number(decimals)).toBe(18);
    messenger.clearEventSubscriptions('NetworkController:stateChange');
  });

  it('gets ERC-20 token name', async () => {
    const { assetsContract, messenger, networkClientConfiguration } =
      await setupAssetContractControllers();
    mockNetworkWithDefaultChainId({
      networkClientConfiguration,
      mocks: [
        {
          request: {
            method: 'eth_call',
            params: [
              {
                to: ERC20_DAI_ADDRESS,
                data: '0x06fdde03',
              },
              'latest',
            ],
          },
          response: {
            result:
              '0x0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000e44616920537461626c65636f696e000000000000000000000000000000000000',
          },
        },
      ],
    });

    const name = await assetsContract.getERC20TokenName(
      ERC20_DAI_ADDRESS,
      'mainnet',
    );

    expect(name).toBe('Dai Stablecoin');
    messenger.clearEventSubscriptions('NetworkController:stateChange');
  });

  it('gets ERC-721 NFT ownership', async () => {
    const { assetsContract, messenger, networkClientConfiguration } =
      await setupAssetContractControllers();
    mockNetworkWithDefaultChainId({
      networkClientConfiguration,
      mocks: [
        {
          request: {
            method: 'eth_call',
            params: [
              {
                to: ERC721_GODS_ADDRESS,
                data: '0x6352211e000000000000000000000000000000000000000000000000000000000002436c',
              },
              'latest',
            ],
          },
          response: {
            result:
              '0x00000000000000000000000017f88211f9648cd2cc9f04874153a12371629acc',
          },
        },
      ],
    });
    const tokenId = await assetsContract.getERC721OwnerOf(
      ERC721_GODS_ADDRESS,
      '148332',
      'mainnet',
    );
    expect(tokenId).not.toBe('');
    messenger.clearEventSubscriptions('NetworkController:stateChange');
  });

  it('throws an error for invalid networkClientId during ERC-721 NFT ownership query', async () => {
    const { assetsContract, messenger } = await setupAssetContractControllers();
    await expect(
      assetsContract.getERC721OwnerOf(
        ERC721_GODS_ADDRESS,
        '148332',
        'invalidNetworkClientId',
      ),
    ).rejects.toThrow('No custom network client was found');
    messenger.clearEventSubscriptions('NetworkController:stateChange');
  });

  it('gets balance of ERC-20 token in a single call on network with token detection support', async () => {
    const { assetsContract, messenger, networkClientConfiguration } =
      await setupAssetContractControllers();
    mockNetworkWithDefaultChainId({
      networkClientConfiguration,
      mocks: [
        {
          request: {
            method: 'eth_call',
            params: [
              {
                to: '0xb1f8e55c7f64d203c1400b9d8555d050f94adf39',
                data: '0xf0002ea900000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000100000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000000000000000000000000000000000000000000100000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359',
              },
              'latest',
            ],
          },
          response: {
            result:
              '0x00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000733ed8ef4c4a0155d09',
          },
        },
      ],
    });
    const balances = await assetsContract.getBalancesInSingleCall(
      ERC20_SAI_ADDRESS,
      [ERC20_SAI_ADDRESS],
      'mainnet',
    );
    expect(balances[ERC20_SAI_ADDRESS]).toBeDefined();
    messenger.clearEventSubscriptions('NetworkController:stateChange');
  });

  it('does not have balance in a single call after switching to network without token detection support', async () => {
    const { assetsContract, messenger, networkClientConfiguration } =
      await setupAssetContractControllers();
    mockNetworkWithDefaultChainId({
      networkClientConfiguration,
      mocks: [
        {
          request: {
            method: 'eth_call',
            params: [
              {
                to: '0xb1f8e55c7f64d203c1400b9d8555d050f94adf39',
                data: '0xf0002ea900000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000100000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000000000000000000000000000000000000000000100000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359',
              },
              'latest',
            ],
          },
          response: {
            result:
              '0x00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000733ed8ef4c4a0155d09',
          },
        },
      ],
    });
    mockNetworkWithDefaultChainId({
      networkClientConfiguration: {
        chainId: BUILT_IN_NETWORKS.sepolia.chainId,
        ticker: BUILT_IN_NETWORKS.sepolia.ticker,
        type: NetworkClientType.Infura,
        network: 'sepolia',
        infuraProjectId: networkClientConfiguration.infuraProjectId,
      },
      mocks: [
        {
          request: {
            method: 'eth_blockNumber',
            params: [],
          },
          response: {
            result: '0x3b3301',
          },
        },
        {
          request: {
            method: 'eth_getBlockByNumber',
            params: ['0x3b3301'],
          },
          response: {
            result:
              '1f8b08000000000000ffb4784dab5d598ee57fb963d3e85bda316c92fe801e340d394a7220696b67b871d881df8bcaa84ae2bf17fb5d674016f6ccf1060fee39f76ae9682f2d2d9d7f3cfeffcba78f9f7feec70f0ffa6ff078f778bf1f3f182106e89220b2507bf7f83c2fbf7c787dfcf08f47e5cbfc8f99ff3b9fff67be3c7e78c0affe78f7d8efcf79dfbf7c78fdf7b74b37d0fcfafa39ff94aff97665473020146888b9a98b4584b91d461a2686fb3fd4da968dabc7e3dde36ff9f27fdefff4fef52d02f66a0e785efef3cbec2f57a5d8e7f1eef163befcf804b72c858283403996284b77837a07e1de75784042fd1c2baba1dca347912a8ad44f3ede3d3e7cfadbcb7ffff0e9d34f6f01491510d616dc6d0e905520001c68828002ba2a09a8383241a0e12c927005e0054511690b51241a122170903b8382e204b4300b9009bb6f615cbaa0e62c68e4ea0029508b850202a8b8023a082a38d1445320ef37f781b5783674c48a5b6c58410204b06498571f6482c60d34a92b8d150e1224181c6b808316dd2148b8a60111a6945712086d4a5060b514819508404d04444b004bee8f041b919745546f290e48912222212829cc8cd1015880ac28b0e070d06e4b206868760900588894b04001066447d36a025f484082042d1b49a25953a821415d30e01e0b8bc126a0458b17b67942808982ec2dda09f0f6c02bc08901e850024224ec869b2440c800219d4c0f38806b48c72fe57e7aff713ebf91a16d4874ad857586bc3b6d8739d161dd499c38d2b5fced47bffeaf7f92b2975cc613982c4346c6341c415db26b8909b1c91a863d5b5720fbb9748a8eb2a0bce13e7efad8f364f87ff9bb377ff9a9be64c8c50cf878f7f8393fcfc7d7df5300d7f1132cdb85a26ec55c8ed1e64c37d3b3706d56176f3845066bf991044c3e86721bf2f3f4bcfff9f5e5ff7dfaf46ccacd0eb3e2a47886069ced195e6b8982b6f90e3f2d21aa1cb750d22b0417642d67a69be5cb8fc97ffed81fe6a926b8bb654fec69d7ed99155a6a5ed6b',
          },
        },
      ],
    });

    const balances = await assetsContract.getBalancesInSingleCall(
      ERC20_SAI_ADDRESS,
      [ERC20_SAI_ADDRESS],
      'mainnet',
    );
    expect(balances[ERC20_SAI_ADDRESS]).toBeDefined();

    const noBalances = await assetsContract.getBalancesInSingleCall(
      ERC20_SAI_ADDRESS,
      [ERC20_SAI_ADDRESS],
      'sepolia',
    );
    expect(noBalances).toStrictEqual({});
    messenger.clearEventSubscriptions('NetworkController:stateChange');
  });

  it('throws an error for invalid networkClientId during single ERC-1155 transfer', async () => {
    const { assetsContract, messenger } = await setupAssetContractControllers();
    await expect(
      assetsContract.transferSingleERC1155(
        ERC1155_ADDRESS,
        TEST_ACCOUNT_PUBLIC_ADDRESS,
        TEST_ACCOUNT_PUBLIC_ADDRESS,
        ERC1155_ID,
        '1',
        'invalidNetworkClientId',
      ),
    ).rejects.toThrow('No custom network client was found');
    messenger.clearEventSubscriptions('NetworkController:stateChange');
  });

  it('gets the balance of a ERC-1155 NFT for a given address', async () => {
    const { assetsContract, messenger, networkClientConfiguration } =
      await setupAssetContractControllers();
    mockNetworkWithDefaultChainId({
      networkClientConfiguration,
      mocks: [
        {
          request: {
            method: 'eth_call',
            params: [
              {
                to: ERC1155_ADDRESS,
                data: '0x00fdd58e0000000000000000000000005a3ca5cd63807ce5e4d7841ab32ce6b6d9bbba2d5a3ca5cd63807ce5e4d7841ab32ce6b6d9bbba2d000000000000010000000001',
              },
              'latest',
            ],
          },
          response: {
            result:
              '0x0000000000000000000000000000000000000000000000000000000000000001',
          },
        },
      ],
    });
    const balance = await assetsContract.getERC1155BalanceOf(
      TEST_ACCOUNT_PUBLIC_ADDRESS,
      ERC1155_ADDRESS,
      ERC1155_ID,
      'mainnet',
    );
    expect(Number(balance)).toBeGreaterThan(0);
    messenger.clearEventSubscriptions('NetworkController:stateChange');
  });

  it('throws an error for invalid networkClientId during ERC-1155 NFT balance query', async () => {
    const { assetsContract, messenger } = await setupAssetContractControllers();
    await expect(
      assetsContract.getERC1155BalanceOf(
        TEST_ACCOUNT_PUBLIC_ADDRESS,
        ERC1155_ADDRESS,
        ERC1155_ID,
        'invalidNetworkClientId',
      ),
    ).rejects.toThrow('No custom network client was found');
    messenger.clearEventSubscriptions('NetworkController:stateChange');
  });

  it('gets the URI of a ERC-1155 NFT', async () => {
    const { assetsContract, messenger, networkClientConfiguration } =
      await setupAssetContractControllers();
    mockNetworkWithDefaultChainId({
      networkClientConfiguration,
      mocks: [
        {
          request: {
            method: 'eth_call',
            params: [
              {
                to: ERC1155_ADDRESS,
                data: '0x0e89341c5a3ca5cd63807ce5e4d7841ab32ce6b6d9bbba2d000000000000010000000001',
              },
              'latest',
            ],
          },
          response: {
            result:
              '0x0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000005868747470733a2f2f6170692e6f70656e7365612e696f2f6170692f76312f6d657461646174612f3078343935663934373237363734394365363436663638414338633234383432303034356362376235652f30787b69647d0000000000000000',
          },
        },
      ],
    });
    const expectedUri = `https://api.opensea.io/api/v1/metadata/${ERC1155_ADDRESS}/0x{id}`;
    const uri = await assetsContract.getERC1155TokenURI(
      ERC1155_ADDRESS,
      ERC1155_ID,
      'mainnet',
    );
    expect(uri.toLowerCase()).toStrictEqual(expectedUri);
    messenger.clearEventSubscriptions('NetworkController:stateChange');
  });
});
